# **App Name**: Glow and Gears

## Core Features:

- Multi-Storefront Product Display: Showcase products from distinct sub-websites (Perfume Wave, Velure Jewels, Toy Kingz, Rupoboti) on their dedicated landing pages.
- Product Detail Pages with Options: Detailed product pages showing images, descriptions, dynamic options like sizes (e.g., 15ML, 30ML, 50ML for perfumes), and an 'Add to Cart' button.
- Shopping Cart Management: Allow users to view, add, or remove items from a dynamic shopping cart, and easily adjust quantities before checkout.
- Bangladeshi Payment Gateway Integration: A streamlined checkout process enabling secure payments via popular Bangladeshi methods (e.g., bKash, Nagad).
- Dynamic Homepage Banner: A prominent, automatically rotating banner slideshow on the main homepage to highlight promotions, featured products, or sub-websites.
- Facebook Business Marketing Tool: An AI-powered tool that assists in generating optimized product descriptions and URL parameters for direct linking to Facebook Business landing pages, facilitating targeted ad boosting campaigns.

## Style Guidelines:

- Primary color: A sophisticated and vibrant purplish-blue (#6220F7) to convey innovation and luxury.
- Background color: A subtle, very light desaturated purple (#EBE9F7) providing a clean and elegant base for content.
- Accent color: A dynamic and inviting blue (#3391FF) for call-to-action elements and interactive features.
- Headline font: 'Space Grotesk', a proportional sans-serif, chosen for a modern and slightly techy aesthetic.
- Body text font: 'Inter', a grotesque-style sans-serif, providing excellent readability for product descriptions and general interface text.
- Utilize modern, clean line icons that align with a premium e-commerce experience across different product categories.
- Adopt a modular, responsive grid layout for consistent display of products and information across all sub-websites and devices.