"use client";

import { ChevronLeft, Truck, Clock, Globe, ShieldCheck } from 'lucide-react';
import Link from 'next/link';

export default function ShippingPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <Link 
        href="/" 
        className="inline-flex items-center text-sm font-bold text-muted-foreground hover:text-primary mb-8 gap-1"
      >
        <ChevronLeft className="w-4 h-4" /> Back to Store
      </Link>

      <div className="space-y-12">
        <header className="space-y-4">
          <h1 className="text-4xl md:text-6xl font-headline font-bold">Shipping Policy</h1>
          <p className="text-muted-foreground text-lg">
            At Glow and Gears, we strive to deliver your luxury items as quickly and safely as possible.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="p-6 bg-white rounded-3xl border space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-headline font-bold">Delivery Charges</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              We offer a flat shipping rate of <strong>100 BDT</strong> for all orders within Bangladesh, regardless of the order size or weight.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-headline font-bold">Delivery Time</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              <strong>Inside Dhaka:</strong> 2-3 business days.<br />
              <strong>Outside Dhaka:</strong> 3-5 business days.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
              <Globe className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-headline font-bold">Coverage</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Currently, we deliver across all 64 districts of Bangladesh. International shipping is not available at this moment.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-headline font-bold">Safe Handling</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              All fragile items like perfumes and jewelry are packed with extra care to ensure they reach you in perfect condition.
            </p>
          </div>
        </div>

        <section className="space-y-6 prose prose-neutral max-w-none">
          <h2 className="text-2xl font-headline font-bold">Detailed Terms</h2>
          <div className="space-y-4 text-muted-foreground">
            <p>
              1. <strong>Order Processing:</strong> All orders are processed within 24 hours of placement. Orders placed on Fridays or public holidays will be processed on the next business day.
            </p>
            <p>
              2. <strong>Tracking:</strong> Once your order is dispatched, you will receive an SMS with your tracking information.
            </p>
            <p>
              3. <strong>Undelivered Packages:</strong> If our delivery partner is unable to reach you after multiple attempts, the package will be returned to our warehouse. A re-delivery charge may apply.
            </p>
            <p>
              4. <strong>Damage Claims:</strong> If you receive a damaged product, please contact our support team within 24 hours of delivery with unboxing proof (video/photo).
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
