
"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Search, Package, Truck, CheckCircle2, Clock, ChevronLeft } from 'lucide-react';
import Link from 'next/link';

type OrderStatus = 'processing' | 'shipped' | 'out-for-delivery' | 'delivered';

interface TrackingInfo {
  id: string;
  status: OrderStatus;
  date: string;
  estimatedDelivery: string;
  items: string[];
}

export default function TrackOrderPage() {
  const [orderId, setOrderId] = useState('');
  const [trackingData, setTrackingData] = useState<TrackingInfo | null>(null);
  const [loading, setLoading] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderId) return;

    setLoading(true);
    // Simulating API call
    setTimeout(() => {
      setTrackingData({
        id: orderId,
        status: 'shipped',
        date: 'Oct 24, 2023',
        estimatedDelivery: 'Oct 28, 2023',
        items: ['Midnight Oud (50ML)', 'Matte Rose Lipstick'],
      });
      setLoading(false);
    }, 1500);
  };

  const steps = [
    { key: 'processing', label: 'Processing', icon: Clock },
    { key: 'shipped', label: 'Shipped', icon: Package },
    { key: 'out-for-delivery', label: 'Out for Delivery', icon: Truck },
    { key: 'delivered', label: 'Delivered', icon: CheckCircle2 },
  ];

  const currentStepIndex = steps.findIndex(s => s.key === trackingData?.status);

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <Link 
        href="/" 
        className="inline-flex items-center text-sm font-bold text-muted-foreground hover:text-primary mb-8 gap-1"
      >
        <ChevronLeft className="w-4 h-4" /> Back to Home
      </Link>

      <div className="space-y-12">
        <header className="space-y-4 text-center md:text-left">
          <h1 className="text-4xl md:text-6xl font-headline font-bold">Track Your Order</h1>
          <p className="text-muted-foreground text-lg">
            Enter your order ID to see the real-time status of your delivery.
          </p>
        </header>

        <Card className="rounded-[32px] shadow-lg border-none bg-white p-2">
          <CardContent className="pt-8">
            <form onSubmit={handleTrack} className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                <Input 
                  placeholder="Enter your Order ID (e.g. GG-12345)" 
                  className="h-14 pl-12 rounded-2xl text-lg font-medium"
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" disabled={loading} className="h-14 px-8 rounded-2xl text-lg font-bold gap-2">
                {loading ? 'Searching...' : 'Track Order'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {trackingData && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom duration-500">
            <Card className="rounded-[32px] border-none shadow-md overflow-hidden bg-white">
              <CardHeader className="bg-primary/5 border-b p-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <CardTitle className="font-headline text-2xl">Order #{trackingData.id}</CardTitle>
                    <CardDescription className="text-base">Placed on {trackingData.date}</CardDescription>
                  </div>
                  <div className="bg-primary text-white px-4 py-2 rounded-full text-sm font-bold uppercase tracking-wider">
                    {trackingData.status.replace(/-/g, ' ')}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
                  {/* Progress Line */}
                  <div className="absolute top-6 left-[12.5%] right-[12.5%] h-0.5 bg-muted hidden md:block" />
                  
                  {steps.map((step, index) => {
                    const Icon = step.icon;
                    const isActive = index <= currentStepIndex;
                    const isCompleted = index < currentStepIndex;

                    return (
                      <div key={step.key} className="flex flex-col items-center text-center space-y-3 relative z-10">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors duration-500 ${
                          isActive ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-muted text-muted-foreground'
                        }`}>
                          <Icon className="w-6 h-6" />
                        </div>
                        <div className="space-y-1">
                          <p className={`font-bold text-sm ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                            {step.label}
                          </p>
                          {isCompleted && <p className="text-[10px] text-green-500 font-bold uppercase">Completed</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-12 p-6 bg-muted/30 rounded-3xl border border-dashed grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Estimated Delivery</p>
                    <p className="text-xl font-headline font-bold">{trackingData.estimatedDelivery}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Items In Package</p>
                    <p className="text-sm font-medium">{trackingData.items.join(', ')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
