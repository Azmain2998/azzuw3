
import { PRODUCTS } from '@/lib/data';
import { ProductCard } from '@/components/shop/ProductCard';
import Image from 'next/image';

export default function AllProductsPage() {
  return (
    <div className="space-y-12 pb-20">
      <div className="relative h-[300px] flex items-center justify-center overflow-hidden">
        <Image 
          src="https://picsum.photos/seed/allstore/1200/600" 
          alt="All Products" 
          fill 
          className="object-cover"
          data-ai-hint="shopping mall"
        />
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
        <div className="relative z-10 container mx-auto px-4 text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-headline font-bold text-white tracking-tight">Full Collection</h1>
          <p className="text-white/80 max-w-xl mx-auto text-lg">Explore our entire range of premium products across all categories.</p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between border-b pb-6 mb-8">
          <h2 className="text-2xl font-headline font-bold">All Items ({PRODUCTS.length})</h2>
          <div className="flex gap-2">
            <span className="text-xs font-bold uppercase text-muted-foreground bg-muted px-2 py-1 rounded">Sort: Featured</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
