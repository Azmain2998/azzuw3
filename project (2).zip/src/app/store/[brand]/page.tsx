import { BRANDS, PRODUCTS } from '@/lib/data';
import { ProductCard } from '@/components/shop/ProductCard';
import { notFound } from 'next/navigation';
import Image from 'next/image';

export default async function BrandPage({ params }: { params: Promise<{ brand: string }> }) {
  const { brand: brandId } = await params;
  
  const brand = BRANDS.find(b => b.id === brandId);
  if (!brand) return notFound();

  const brandProducts = PRODUCTS.filter(p => p.brandId === brandId);

  return (
    <div className="space-y-12 pb-20">
      <div className="relative h-[300px] flex items-center justify-center overflow-hidden">
        <Image 
          src={brand.bannerImage} 
          alt={brand.name} 
          fill 
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
        <div className="relative z-10 container mx-auto px-4 text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-headline font-bold text-white tracking-tight">{brand.name}</h1>
          <p className="text-white/80 max-w-xl mx-auto text-lg">{brand.description}</p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between border-b pb-6 mb-8">
          <h2 className="text-2xl font-headline font-bold">Store Items ({brandProducts.length})</h2>
          <div className="flex gap-2">
            <span className="text-xs font-bold uppercase text-muted-foreground bg-muted px-2 py-1 rounded">Sort: Best Selling</span>
          </div>
        </div>

        {brandProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {brandProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 space-y-4">
            <p className="text-muted-foreground text-xl">We are restocking our collection. Check back soon!</p>
          </div>
        )}
      </div>
    </div>
  );
}
