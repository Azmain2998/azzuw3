"use client";

import { useState } from 'react';
import { generateFacebookAdContent, type GenerateFacebookAdContentOutput } from '@/ai/flows/generate-facebook-ad-content';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PRODUCTS, BRANDS } from '@/lib/data';
import { 
  Sparkles, 
  Facebook, 
  ExternalLink, 
  Copy, 
  Layout, 
  Type, 
  Image as ImageIcon,
  Rocket,
  Loader2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export default function MarketingStudio() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateFacebookAdContentOutput | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    productName: '',
    productDescription: '',
    productPrice: '',
    productCategory: '',
    productUrl: '',
    targetAudience: 'Fashion-forward individuals in Bangladesh interested in premium luxury brands.',
    keyFeatures: ''
  });

  const selectProduct = (p: typeof PRODUCTS[0]) => {
    const brand = BRANDS.find(b => b.id === p.brandId);
    setFormData({
      productName: p.name,
      productDescription: p.description,
      productPrice: `${p.price} ${p.currency}`,
      productCategory: brand?.name || p.brandId,
      productUrl: `${window.location.origin}/product/${p.id}`,
      targetAudience: `People interested in ${brand?.name || 'lifestyle'} products.`,
      keyFeatures: p.options ? p.options.join(', ') : ''
    });
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const output = await generateFacebookAdContent({
        ...formData,
        keyFeatures: formData.keyFeatures.split(',').map(f => f.trim())
      });
      setResult(output);
      toast({
        title: "Ad Content Generated!",
        description: "Your Facebook ad is ready for review.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: "Something went wrong while generating the ad.",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!", description: "Content copied to clipboard." });
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-xs">
            <Sparkles className="w-4 h-4" />
            AI Marketing Studio
          </div>
          <h1 className="text-4xl md:text-6xl font-headline font-bold">Facebook AD Studio</h1>
          <p className="text-muted-foreground text-lg max-w-xl">Generate high-converting Facebook Ads and tracking links for your Glow & Gears products.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <section className="space-y-8">
          <Card className="rounded-[40px] shadow-sm border-none bg-white p-2">
            <CardHeader className="pb-4">
              <CardTitle className="font-headline text-2xl">Step 1: Product Data</CardTitle>
              <CardDescription>Select a product or enter details manually.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-wrap gap-2 pb-6">
                {PRODUCTS.slice(0, 4).map(p => (
                  <button 
                    key={p.id}
                    onClick={() => selectProduct(p)}
                    className="flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-xl bg-muted hover:bg-primary hover:text-white transition-colors border"
                  >
                    <div className="w-5 h-5 relative rounded-md overflow-hidden bg-white">
                      <Image src={p.image} alt={p.name} fill className="object-cover" />
                    </div>
                    {p.name}
                  </button>
                ))}
              </div>

              <form onSubmit={handleGenerate} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Product Name</Label>
                    <Input 
                      value={formData.productName} 
                      onChange={e => setFormData({...formData, productName: e.target.value})}
                      placeholder="e.g. Midnight Oud"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Price</Label>
                    <Input 
                      value={formData.productPrice} 
                      onChange={e => setFormData({...formData, productPrice: e.target.value})}
                      placeholder="e.g. 500 BDT"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Base Landing Page URL</Label>
                  <Input 
                    type="url"
                    value={formData.productUrl} 
                    onChange={e => setFormData({...formData, productUrl: e.target.value})}
                    placeholder="https://glowandgears.com/product/..."
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea 
                    value={formData.productDescription} 
                    onChange={e => setFormData({...formData, productDescription: e.target.value})}
                    placeholder="Describe the product..."
                    className="h-24"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Target Audience</Label>
                  <Input 
                    value={formData.targetAudience} 
                    onChange={e => setFormData({...formData, targetAudience: e.target.value})}
                    placeholder="Describe your ideal customer..."
                  />
                </div>

                <Button 
                  type="submit" 
                  disabled={loading}
                  className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-lg font-bold gap-2"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Rocket className="w-5 h-5" />}
                  Generate Ad Content
                </Button>
              </form>
            </CardContent>
          </Card>
        </section>

        <section className="space-y-8">
          {!result && !loading && (
            <div className="h-full flex flex-col items-center justify-center p-12 text-center border-2 border-dashed rounded-[40px] space-y-4 bg-muted/20">
              <Layout className="w-16 h-16 text-muted-foreground/30" />
              <div className="space-y-1">
                <h3 className="font-headline font-bold text-xl">Preview Studio</h3>
                <p className="text-muted-foreground">Your generated ad content will appear here.</p>
              </div>
            </div>
          )}

          {loading && (
            <div className="h-full flex flex-col items-center justify-center p-12 text-center border-2 border-dashed rounded-[40px] space-y-4 bg-primary/5">
              <Loader2 className="w-16 h-16 text-primary animate-spin" />
              <div className="space-y-1">
                <h3 className="font-headline font-bold text-xl text-primary">AI is crafting your ad...</h3>
                <p className="text-muted-foreground">This usually takes about 5-10 seconds.</p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom duration-500">
              <Card className="rounded-[40px] border-none shadow-xl bg-white overflow-hidden">
                <CardHeader className="bg-primary text-white p-8">
                  <div className="flex items-center justify-between">
                    <CardTitle className="font-headline text-2xl flex items-center gap-2">
                      <Facebook className="w-6 h-6" /> Facebook Preview
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button variant="secondary" size="icon" onClick={() => copyToClipboard(result.adBody)} className="rounded-full">
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div className="space-y-4 border p-6 rounded-3xl bg-muted/10">
                    <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase">
                      <Type className="w-4 h-4" /> Recommended Headline
                    </div>
                    <h3 className="text-2xl font-headline font-bold leading-tight">{result.adHeadline}</h3>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase">
                      <Layout className="w-4 h-4" /> Ad Copy (Body)
                    </div>
                    <p className="text-muted-foreground leading-relaxed italic border-l-4 border-primary/20 pl-4">
                      {result.adBody}
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase">
                      <ImageIcon className="w-4 h-4" /> Visual Concept
                    </div>
                    <div className="bg-muted p-4 rounded-2xl text-sm border">
                      {result.suggestedAdImageDescription}
                    </div>
                  </div>

                  <div className="space-y-4 pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase">
                        <ExternalLink className="w-4 h-4" /> Smart Tracking URL
                      </div>
                      <Button variant="outline" size="sm" onClick={() => copyToClipboard(result.facebookLandingPageUrl)} className="h-8 rounded-full text-xs font-bold">
                        Copy Link
                      </Button>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-2xl border font-mono text-[10px] break-all text-muted-foreground">
                      {result.facebookLandingPageUrl}
                    </div>
                  </div>

                  <Button className="w-full h-14 rounded-2xl font-bold text-lg gap-2" asChild>
                    <a href={result.facebookLandingPageUrl} target="_blank" rel="noopener noreferrer">
                      Test Landing Page <ExternalLink className="w-5 h-5" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
