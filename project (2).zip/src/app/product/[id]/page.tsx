"use client";

import { PRODUCTS } from '@/lib/data';
import { notFound, useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { useCart } from '@/hooks/use-cart';
import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { ShoppingBag, CreditCard, ChevronLeft, Star, Share2 } from 'lucide-react';
import Link from 'next/link';

export default function ProductPage() {
  const { id } = useParams();
  const router = useRouter();
  const { addItem } = useCart();
  
  const product = PRODUCTS.find(p => p.id === id);
  if (!product) return notFound();

  const [selectedOption, setSelectedOption] = useState(product.options?.[0] || '');
  const [quantity, setQuantity] = useState(1);

  const displayPrice = useMemo(() => {
    if (product.optionPrices && selectedOption) {
      return product.optionPrices[selectedOption];
    }
    return product.price;
  }, [product, selectedOption]);

  const handleAddToCart = () => {
    addItem(product, quantity, selectedOption);
  };

  const handleBuyNow = () => {
    addItem(product, quantity, selectedOption);
    router.push('/checkout');
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <Link 
        href={`/store/${product.brandId}`} 
        className="inline-flex items-center text-sm font-bold text-muted-foreground hover:text-primary mb-8 gap-1"
      >
        <ChevronLeft className="w-4 h-4" /> Back to Collection
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 xl:gap-24">
        <div className="space-y-4">
          <div className="relative aspect-square rounded-3xl overflow-hidden bg-muted shadow-2xl">
            <Image 
              src={product.image} 
              alt={product.name} 
              fill 
              className="object-cover"
              priority
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="relative aspect-square rounded-xl bg-muted overflow-hidden cursor-pointer hover:ring-2 ring-primary transition-all">
                <Image src={product.image} alt="Thumbnail" fill className="object-cover opacity-60 hover:opacity-100" />
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-primary font-bold uppercase tracking-widest text-xs">{product.brandId.replace('-', ' ')}</span>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
            <h1 className="text-4xl md:text-5xl font-headline font-bold leading-tight">{product.name}</h1>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-0.5 text-yellow-500">
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4" />
              </div>
              <span className="text-sm text-muted-foreground">(4.0 • 24 reviews)</span>
            </div>
          </div>

          <p className="text-3xl font-headline font-bold text-primary">{displayPrice} {product.currency}</p>

          <p className="text-muted-foreground leading-relaxed text-lg">
            {product.description}
          </p>

          {product.options && (
            <div className="space-y-4">
              <Label className="text-base font-bold font-headline">{product.optionsLabel}</Label>
              <RadioGroup 
                value={selectedOption} 
                onValueChange={setSelectedOption}
                className="flex flex-wrap gap-3"
              >
                {product.options.map((opt) => (
                  <div key={opt}>
                    <RadioGroupItem value={opt} id={opt} className="peer sr-only" />
                    <Label
                      htmlFor={opt}
                      className="flex h-12 min-w-[60px] items-center justify-center rounded-xl border-2 px-4 font-bold cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 peer-data-[state=checked]:text-primary"
                    >
                      {opt}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          <div className="space-y-4">
            <Label className="text-base font-bold font-headline">Quantity</Label>
            <div className="flex items-center border-2 rounded-xl w-fit p-1">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="h-10 w-10 font-bold"
              >
                -
              </Button>
              <span className="w-12 text-center font-bold">{quantity}</span>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setQuantity(quantity + 1)}
                className="h-10 w-10 font-bold"
              >
                +
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6">
            <Button 
              size="lg" 
              variant="outline"
              className="h-14 rounded-2xl font-bold text-lg gap-2 border-2"
              onClick={handleAddToCart}
            >
              <ShoppingBag className="w-5 h-5" />
              Add to Cart
            </Button>
            <Button 
              size="lg" 
              className="h-14 rounded-2xl font-bold text-lg gap-2 bg-primary hover:bg-primary/90"
              onClick={handleBuyNow}
            >
              <CreditCard className="w-5 h-5" />
              Buy It Now
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-6 pt-12 border-t text-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                <CreditCard className="w-5 h-5" />
              </div>
              <div className="font-bold">Safe Payments</div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                <Star className="w-5 h-5" />
              </div>
              <div className="font-bold">Quality Guaranteed</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
