"use client";

import { useCart } from '@/hooks/use-cart';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ChevronLeft, CreditCard, ShieldCheck, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import Image from 'next/image';

export default function CheckoutPage() {
  const { items, totalPrice } = useCart();
  const [paymentMethod, setPaymentMethod] = useState('bkash');
  const [orderComplete, setOrderComplete] = useState(false);

  if (items.length === 0 && !orderComplete) {
    return (
      <div className="container mx-auto px-4 py-20 text-center space-y-4">
        <h1 className="text-3xl font-headline font-bold">Your cart is empty</h1>
        <Button asChild><Link href="/">Back to Home</Link></Button>
      </div>
    );
  }

  if (orderComplete) {
    return (
      <div className="container mx-auto px-4 py-24 text-center max-w-xl space-y-8">
        <div className="flex justify-center">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600">
            <CheckCircle2 className="w-16 h-16" />
          </div>
        </div>
        <div className="space-y-4">
          <h1 className="text-4xl font-headline font-bold">Order Confirmed!</h1>
          <p className="text-muted-foreground text-lg">Thank you for shopping with Glow and Gears. Your order has been placed and we'll notify you once it's on its way.</p>
        </div>
        <div className="bg-muted/50 p-6 rounded-3xl border">
          <p className="font-bold text-sm text-muted-foreground uppercase tracking-widest mb-2">Order Summary</p>
          <div className="flex justify-between items-center text-2xl font-headline font-bold">
            <span>Amount Paid</span>
            <span className="text-primary">{totalPrice} BDT</span>
          </div>
        </div>
        <Button asChild size="lg" className="w-full h-14 rounded-2xl font-bold text-lg"><Link href="/">Continue Shopping</Link></Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <Link href="/" className="inline-flex items-center text-sm font-bold text-muted-foreground hover:text-primary mb-8 gap-1">
        <ChevronLeft className="w-4 h-4" /> Back to Store
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <section className="space-y-6">
            <h2 className="text-2xl font-headline font-bold flex items-center gap-2">
              <span className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm">1</span>
              Shipping Information
            </h2>
            <Card className="rounded-3xl shadow-none">
              <CardContent className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="Mominur" className="h-12 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Rahman" className="h-12 rounded-xl" />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input id="address" placeholder="123 Dhanmondi, Dhaka" className="h-12 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input id="city" placeholder="Dhaka" className="h-12 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" placeholder="01712-XXXXXX" className="h-12 rounded-xl" />
                </div>
              </CardContent>
            </Card>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-headline font-bold flex items-center gap-2">
              <span className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm">2</span>
              Payment Method
            </h2>
            <Card className="rounded-3xl shadow-none overflow-hidden">
              <CardContent className="p-0">
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="grid grid-cols-1 divide-y">
                  <div className="flex items-center justify-between p-6">
                    <Label htmlFor="bkash" className="flex items-center gap-4 font-bold text-lg cursor-pointer w-full">
                      <RadioGroupItem value="bkash" id="bkash" />
                      <div className="flex-1 flex items-center justify-between">
                        <span>bKash Payment</span>
                        <div className="w-12 h-12 bg-pink-500 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">bKash</div>
                      </div>
                    </Label>
                  </div>
                  <div className="flex items-center justify-between p-6">
                    <Label htmlFor="nagad" className="flex items-center gap-4 font-bold text-lg cursor-pointer w-full">
                      <RadioGroupItem value="nagad" id="nagad" />
                      <div className="flex-1 flex items-center justify-between">
                        <span>Nagad Payment</span>
                        <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">Nagad</div>
                      </div>
                    </Label>
                  </div>
                  <div className="flex items-center justify-between p-6">
                    <Label htmlFor="cod" className="flex items-center gap-4 font-bold text-lg cursor-pointer w-full">
                      <RadioGroupItem value="cod" id="cod" />
                      <div className="flex-1 flex items-center justify-between">
                        <span>Cash on Delivery</span>
                        <div className="w-12 h-12 bg-gray-500 rounded-lg flex items-center justify-center text-white text-[10px] font-bold uppercase">COD</div>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>
          </section>
        </div>

        <div className="space-y-8">
          <Card className="rounded-3xl shadow-lg border-primary/20 bg-white sticky top-24">
            <CardHeader>
              <CardTitle className="font-headline">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                {items.map((item) => (
                  <div key={`${item.id}-${item.selectedOption}`} className="flex justify-between items-start gap-4">
                    <div className="flex gap-3">
                      <div className="relative w-12 h-12 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                        <Image src={item.image} alt={item.name} fill className="object-cover" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-bold leading-tight">{item.name}</p>
                        <p className="text-[10px] text-muted-foreground uppercase">Qty: {item.quantity} {item.selectedOption && `• ${item.selectedOption}`}</p>
                      </div>
                    </div>
                    <p className="text-sm font-bold whitespace-nowrap">{item.price * item.quantity} BDT</p>
                  </div>
                ))}
              </div>

              <Separator />
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-medium">{totalPrice} BDT</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping (Flat)</span>
                  <span className="font-medium">100 BDT</span>
                </div>
                <div className="flex justify-between text-xl font-headline font-bold pt-4">
                  <span>Total</span>
                  <span className="text-primary">{totalPrice + 100} BDT</span>
                </div>
              </div>

              <div className="bg-primary/5 p-4 rounded-2xl flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-primary shrink-0" />
                <p className="text-xs text-muted-foreground">Your transaction is secured with industry-standard encryption. We never store your full payment details.</p>
              </div>

              <Button 
                size="lg" 
                className="w-full h-14 rounded-2xl font-bold text-lg bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20"
                onClick={() => setOrderComplete(true)}
              >
                Place Order Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
