import { HeroBanner } from '@/components/home/HeroBanner';
import { BRANDS, PRODUCTS } from '@/lib/data';
import { ProductCard } from '@/components/shop/ProductCard';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export default function Home() {
  const featuredProducts = PRODUCTS.filter(p => p.featured);

  return (
    <div className="space-y-16 pb-20">
      <HeroBanner />

      <section className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-end justify-between gap-4 mb-8">
          <div className="space-y-2">
            <h2 className="text-3xl md:text-4xl font-headline font-bold">Featured Collections</h2>
            <p className="text-muted-foreground max-w-lg">Discover handpicked premium items from our curated sub-brands.</p>
          </div>
          <Button variant="link" asChild className="text-primary font-bold">
            <Link href="/store/all" className="flex items-center gap-1">
              Shop All Products <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="bg-primary/5 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl md:text-5xl font-headline font-bold">Explore Our World</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Glow and Gears houses distinct brands, each dedicated to bringing quality and style to your lifestyle.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {BRANDS.map((brand) => (
              <Link 
                key={brand.id} 
                href={`/store/${brand.id}`}
                className="group relative h-[300px] rounded-3xl overflow-hidden shadow-lg"
              >
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                  style={{ backgroundImage: `url(${brand.bannerImage})` }}
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />
                <div className="absolute inset-0 p-8 flex flex-col justify-end">
                  <h3 className="text-white text-3xl font-headline font-bold mb-2">{brand.name}</h3>
                  <p className="text-white/80 text-sm max-w-xs mb-4 line-clamp-2">{brand.description}</p>
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    Explore Now <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
