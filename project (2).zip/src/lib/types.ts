export type BrandId = 'perfume-wave' | 'velure-jewels' | 'toy-kingz' | 'rupoboti';

export interface Brand {
  id: BrandId;
  name: string;
  description: string;
  bannerImage: string;
  accentColor: string;
}

export interface Product {
  id: string;
  brandId: BrandId;
  name: string;
  description: string;
  price: number;
  currency: string;
  image: string;
  optionsLabel?: string;
  options?: string[];
  optionPrices?: Record<string, number>;
  category: string;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
  selectedOption?: string;
}
