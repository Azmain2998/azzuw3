import { Brand, Product } from './types';
import { PlaceHolderImages } from './placeholder-images';

export const BRANDS: Brand[] = [
  {
    id: 'perfume-wave',
    name: 'Perfume Wave',
    description: 'Ethereal scents for the modern soul. High-quality fragrances crafted with precision.',
    bannerImage: PlaceHolderImages.find(img => img.id === 'hero-1')?.imageUrl || '',
    accentColor: '#3391FF'
  },
  {
    id: 'velure-jewels',
    name: 'Velure Jewels',
    description: 'Exquisite jewelry pieces that tell a story of elegance and timeless beauty.',
    bannerImage: PlaceHolderImages.find(img => img.id === 'hero-2')?.imageUrl || '',
    accentColor: '#6220F7'
  },
  {
    id: 'toy-kingz',
    name: 'Toy Kingz',
    description: 'Bringing joy to every child. The ultimate destination for premium toys and games.',
    bannerImage: PlaceHolderImages.find(img => img.id === 'hero-3')?.imageUrl || '',
    accentColor: '#FF6B6B'
  },
  {
    id: 'rupoboti',
    name: 'Rupoboti',
    description: 'Celebrate your natural beauty with our range of luxury cosmetics and skin care.',
    bannerImage: 'https://picsum.photos/seed/beauty/1200/600',
    accentColor: '#FF4D8D'
  }
];

export const PRODUCTS: Product[] = [
  // Perfume Wave
  {
    id: 'pw-1',
    brandId: 'perfume-wave',
    name: 'Midnight Oud',
    description: 'A deep, mysterious fragrance with notes of oud, rose, and amber.',
    price: 350,
    currency: 'BDT',
    image: PlaceHolderImages.find(img => img.id === 'p-fragrance-1')?.imageUrl || '',
    category: 'Fragrance',
    optionsLabel: 'Size',
    options: ['15ML', '30ML', '50ML'],
    optionPrices: {
      '15ML': 350,
      '30ML': 550,
      '50ML': 860
    },
    featured: true
  },
  {
    id: 'pw-2',
    brandId: 'perfume-wave',
    name: 'Ocean Breeze',
    description: 'Fresh citrus and sea salt notes for a refreshing daily wear.',
    price: 350,
    currency: 'BDT',
    image: 'https://picsum.photos/seed/pw2/600/600',
    category: 'Fragrance',
    optionsLabel: 'Size',
    options: ['15ML', '30ML', '50ML'],
    optionPrices: {
      '15ML': 350,
      '30ML': 550,
      '50ML': 860
    }
  },
  // Velure Jewels
  {
    id: 'vj-1',
    brandId: 'velure-jewels',
    name: 'Golden Blossom Necklace',
    description: 'Handcrafted 18k gold plated necklace with a minimalist floral design.',
    price: 12000,
    currency: 'BDT',
    image: PlaceHolderImages.find(img => img.id === 'p-jewelry-1')?.imageUrl || '',
    category: 'Necklace',
    featured: true
  },
  // Toy Kingz
  {
    id: 'tk-1',
    brandId: 'toy-kingz',
    name: 'Technic Race Car',
    description: 'Advanced building set for aspiring engineers and car enthusiasts.',
    price: 4500,
    currency: 'BDT',
    image: 'https://picsum.photos/seed/tk1/600/600',
    category: 'Building Sets',
    featured: true
  },
  // Rupoboti
  {
    id: 'rp-1',
    brandId: 'rupoboti',
    name: 'Matte Rose Lipstick',
    description: 'Long-lasting matte finish with moisturizing silk proteins.',
    price: 1200,
    currency: 'BDT',
    image: PlaceHolderImages.find(img => img.id === 'p-beauty-1')?.imageUrl || '',
    category: 'Makeup',
    featured: true
  }
];
