
"use client";

import Link from 'next/link';
import { ShoppingBag, Menu, Search, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/use-cart';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { CartSheet } from '../shop/CartSheet';
import { BRANDS } from '@/lib/data';
import { useState } from 'react';

export function Navbar() {
  const { totalItems } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="hover:bg-primary/10">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px] p-0">
              <SheetHeader className="p-6 border-b text-left">
                <SheetTitle className="font-headline font-bold text-xl flex items-center gap-2">
                  <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white text-sm">G</div>
                  Glow & Gears
                </SheetTitle>
              </SheetHeader>
              <div className="py-6 flex flex-col">
                <div className="px-6 mb-4">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-4">Collections</p>
                  <nav className="flex flex-col gap-2">
                    {BRANDS.map(brand => (
                      <Link 
                        key={brand.id} 
                        href={`/store/${brand.id}`}
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center justify-between p-3 rounded-xl hover:bg-primary/5 group transition-colors"
                      >
                        <span className="font-bold text-lg group-hover:text-primary transition-colors">{brand.name}</span>
                        <div className="w-2 h-2 rounded-full bg-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                      </Link>
                    ))}
                  </nav>
                </div>
                
                <div className="px-6 pt-6 border-t mt-auto">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-4">Quick Links</p>
                  <Link 
                    href="/track-order" 
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-primary/5 font-bold text-primary transition-colors"
                  >
                    <Search className="w-5 h-5" />
                    Track My Order
                  </Link>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-xl group-hover:scale-105 transition-transform">
              G
            </div>
            <span className="font-headline font-bold text-xl tracking-tight hidden sm:inline-block">
              Glow & Gears
            </span>
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="hidden sm:flex" asChild>
            <Link href="/track-order"><Search className="w-5 h-5" /></Link>
          </Button>
          
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="relative gap-2 font-semibold h-11 px-5 rounded-xl border-2">
                <ShoppingBag className="w-5 h-5" />
                <span className="hidden sm:inline">Cart</span>
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-white text-[10px] w-6 h-6 rounded-full flex items-center justify-center border-2 border-background font-bold">
                    {totalItems}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-md p-0">
              <CartSheet />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
