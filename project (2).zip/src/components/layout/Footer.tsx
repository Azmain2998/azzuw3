
"use client";

import Link from 'next/link';
import { BRANDS } from '@/lib/data';
import { useEffect, useState } from 'react';

export function Footer() {
  const [year, setYear] = useState<number | null>(null);

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  return (
    <footer className="bg-white border-t py-12 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-lg group-hover:scale-105 transition-transform">
                G
              </div>
              <span className="font-headline font-bold text-lg tracking-tight">
                Glow & Gears
              </span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Premium multi-store e-commerce experience in Bangladesh. Bringing innovation and luxury to your doorstep.
            </p>
          </div>
          
          <div className="space-y-4">
            <h4 className="font-headline font-bold text-sm uppercase tracking-widest text-primary">Our Brands</h4>
            <ul className="space-y-2 text-sm text-muted-foreground font-medium">
              {BRANDS.map(brand => (
                <li key={brand.id}>
                  <Link href={`/store/${brand.id}`} className="hover:text-primary transition-colors">
                    {brand.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-headline font-bold text-sm uppercase tracking-widest text-primary">Customer Care</h4>
            <ul className="space-y-2 text-sm text-muted-foreground font-medium">
              <li><Link href="/track-order" className="hover:text-primary transition-colors font-bold text-primary/80">Track My Order</Link></li>
              <li><Link href="/shipping-policy" className="hover:text-primary transition-colors">Shipping Policy</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Returns & Refunds</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Contact Support</Link></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-headline font-bold text-sm uppercase tracking-widest text-primary">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground font-medium">
              <li><Link href="#" className="hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] sm:text-xs text-muted-foreground font-bold uppercase tracking-widest">
          <p>© {year || '2025'} Glow and Gears. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Crafted with passion in Bangladesh</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
