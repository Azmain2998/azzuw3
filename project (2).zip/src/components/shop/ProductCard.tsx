"use client";

import { Product } from '@/lib/types';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingBag, ArrowRight } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useCart } from '@/hooks/use-cart';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();

  return (
    <Card className="group overflow-hidden bg-white border-none shadow-sm hover:shadow-xl transition-all duration-300">
      <Link href={`/product/${product.id}`}>
        <div className="relative aspect-square overflow-hidden bg-muted">
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute top-2 left-2">
            <span className="bg-white/90 backdrop-blur-sm text-[10px] font-bold px-2 py-1 rounded-full text-primary uppercase">
              {product.brandId.replace('-', ' ')}
            </span>
          </div>
        </div>
      </Link>
      <CardContent className="p-4 space-y-1">
        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{product.category}</p>
        <Link href={`/product/${product.id}`} className="block">
          <h3 className="font-bold text-lg leading-tight group-hover:text-primary transition-colors line-clamp-1">{product.name}</h3>
        </Link>
        <div className="flex items-center justify-between pt-1">
          <p className="text-primary font-bold font-headline text-lg">{product.price} {product.currency}</p>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 gap-2">
        <Button 
          variant="default" 
          className="flex-1 font-bold gap-2"
          onClick={() => addItem(product, 1, product.options ? product.options[0] : undefined)}
        >
          <ShoppingBag className="w-4 h-4" />
          Add
        </Button>
        <Button variant="outline" size="icon" asChild>
          <Link href={`/product/${product.id}`}>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
