"use client";

import { useCart } from '@/hooks/use-cart';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Trash2, Plus, Minus, ShoppingCart } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { SheetHeader, SheetTitle } from '../ui/sheet';

export function CartSheet() {
  const { items, removeItem, updateQuantity, totalPrice, totalItems } = useCart();

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center space-y-4">
        <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
          <ShoppingCart className="w-10 h-10 text-muted-foreground" />
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-headline font-bold">Your bag is empty</h3>
          <p className="text-muted-foreground">Look like you haven't added anything to your cart yet.</p>
        </div>
        <Button asChild className="w-full">
          <Link href="/">Continue Shopping</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <SheetHeader className="p-6 border-b">
        <SheetTitle className="font-headline">Your Shopping Bag ({totalItems})</SheetTitle>
      </SheetHeader>
      
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {items.map((item) => (
          <div key={`${item.id}-${item.selectedOption}`} className="flex gap-4">
            <div className="relative w-20 h-20 bg-muted rounded-lg overflow-hidden flex-shrink-0">
              <Image 
                src={item.image} 
                alt={item.name} 
                fill 
                className="object-cover"
              />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex justify-between">
                <h4 className="font-bold text-sm leading-tight">{item.name}</h4>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-destructive"
                  onClick={() => removeItem(item.id, item.selectedOption)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              {item.selectedOption && (
                <p className="text-xs text-muted-foreground">{item.optionsLabel}: {item.selectedOption}</p>
              )}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center border rounded-md">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7"
                    onClick={() => updateQuantity(item.id, item.quantity - 1, item.selectedOption)}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="w-8 text-center text-xs font-bold">{item.quantity}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7"
                    onClick={() => updateQuantity(item.id, item.quantity + 1, item.selectedOption)}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
                <p className="font-bold text-sm">{item.price * item.quantity} {item.currency}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="p-6 border-t bg-muted/20 space-y-4">
        <div className="space-y-1.5">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span>{totalPrice} BDT</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Shipping</span>
            <span className="text-green-600 font-medium">Calculated at next step</span>
          </div>
          <Separator className="my-2" />
          <div className="flex justify-between text-lg font-bold font-headline">
            <span>Total</span>
            <span className="text-primary">{totalPrice} BDT</span>
          </div>
        </div>
        <Button asChild className="w-full h-12 text-lg font-bold" size="lg">
          <Link href="/checkout">Checkout Now</Link>
        </Button>
      </div>
    </div>
  );
}
