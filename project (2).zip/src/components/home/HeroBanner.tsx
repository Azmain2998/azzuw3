"use client";

import React, { useState, useEffect, useCallback } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { BRANDS } from '@/lib/data';

export function HeroBanner() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);
  }, [emblaApi, onSelect]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (emblaApi) emblaApi.scrollNext();
    }, 5000);
    return () => clearInterval(timer);
  }, [emblaApi]);

  return (
    <div className="relative overflow-hidden group">
      <div className="overflow-hidden" ref={emblaRef}>
        <div className="flex">
          {BRANDS.map((brand) => (
            <div key={brand.id} className="relative flex-[0_0_100%] min-h-[400px] md:min-h-[600px] flex items-center">
              <Image
                src={brand.bannerImage}
                alt={brand.name}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/40 to-transparent flex items-center">
                <div className="container mx-auto px-4 md:px-12">
                  <div className="max-w-xl space-y-4 md:space-y-6 animate-in slide-in-from-left duration-1000">
                    <span className="inline-block px-3 py-1 bg-primary/10 text-primary font-bold rounded-full text-xs uppercase tracking-widest">
                      Featured Brand
                    </span>
                    <h1 className="text-4xl md:text-7xl font-headline font-bold text-foreground leading-tight">
                      {brand.name}
                    </h1>
                    <p className="text-lg text-muted-foreground font-medium md:max-w-md">
                      {brand.description}
                    </p>
                    <div className="flex gap-4">
                      <Button asChild size="lg" className="rounded-full px-8 h-12 font-bold text-lg shadow-lg shadow-primary/20">
                        <Link href={`/store/${brand.id}`}>Shop Collection</Link>
                      </Button>
                      <Button variant="outline" asChild size="lg" className="rounded-full px-8 h-12 font-bold text-lg bg-white/50 backdrop-blur-sm">
                        <Link href="/store/all">View All</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {BRANDS.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all ${
              index === selectedIndex ? "w-8 bg-primary" : "bg-primary/20"
            }`}
            onClick={() => emblaApi?.scrollTo(index)}
          />
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 backdrop-blur-sm"
        onClick={scrollPrev}
      >
        <ChevronLeft className="w-5 h-5" />
      </Button>
      <Button
        variant="outline"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 backdrop-blur-sm"
        onClick={scrollNext}
      >
        <ChevronRight className="w-5 h-5" />
      </Button>
    </div>
  );
}
