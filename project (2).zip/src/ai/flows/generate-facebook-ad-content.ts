'use server';
/**
 * @fileOverview A Genkit flow for generating Facebook ad content, including compelling product descriptions
 * and optimized landing page URLs for targeted ad campaigns.
 *
 * - generateFacebookAdContent - A function that handles the generation of Facebook ad content.
 * - GenerateFacebookAdContentInput - The input type for the generateFacebookAdContent function.
 * - GenerateFacebookAdContentOutput - The return type for the generateFacebookAdContent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateFacebookAdContentInputSchema = z.object({
  productName: z.string().describe('The name of the product.'),
  productDescription: z.string().describe('The existing description of the product.'),
  productPrice: z.string().describe('The price of the product (e.g., "500 BDT").'),
  productCategory: z.string().describe('The category of the product (e.g., "Perfume", "Jewelry").'),
  productUrl: z.string().url().describe('The base URL of the product landing page.'),
  targetAudience: z.string().describe('A description of the ideal target audience for the ad.'),
  keyFeatures: z.array(z.string()).describe('A list of key features or selling points of the product.').optional(),
});
export type GenerateFacebookAdContentInput = z.infer<typeof GenerateFacebookAdContentInputSchema>;

const GenerateFacebookAdContentOutputSchema = z.object({
  adHeadline: z.string().describe('A catchy and engaging headline for the Facebook ad.'),
  adBody: z.string().describe('A compelling and persuasive product description for the Facebook ad body.'),
  callToAction: z.string().describe('A clear call-to-action phrase (e.g., "Shop Now", "Learn More").'),
  campaignIdentifier: z
    .string()
    .describe(
      'A short, URL-friendly identifier for the Facebook campaign, used in UTM parameters (e.g., "perfume-wave-launch").'
    ),
  facebookLandingPageUrl: z
    .string()
    .url()
    .describe(
      'The full optimized landing page URL for Facebook, including UTM parameters for tracking (utm_source, utm_medium, utm_campaign).'
    ),
  suggestedAdImageDescription: z.string().describe('A textual description of an ideal image or video for the Facebook ad.'),
});
export type GenerateFacebookAdContentOutput = z.infer<typeof GenerateFacebookAdContentOutputSchema>;

export async function generateFacebookAdContent(
  input: GenerateFacebookAdContentInput
): Promise<GenerateFacebookAdContentOutput> {
  return generateFacebookAdContentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateFacebookAdContentPrompt',
  input: {schema: GenerateFacebookAdContentInputSchema},
  output: {schema: GenerateFacebookAdContentOutputSchema},
  prompt: `You are an expert Facebook ad copywriter and marketing strategist for an e-commerce website named "Glow and Gears".
Your task is to generate compelling ad content for a product, including a headline, ad body, call to action, and a campaign identifier for URL tracking.

Product Name: {{{productName}}}
Product Description: {{{productDescription}}}
Product Price: {{{productPrice}}}
Product Category: {{{productCategory}}}
Target Audience: {{{targetAudience}}}
{{#if keyFeatures}}
Key Features: {{#each keyFeatures}}- {{{this}}}
{{/each}}{{/if}}

Instructions:
1.  **Ad Headline**: Create a short, catchy, and attention-grabbing headline (maximum 10-15 words).
2.  **Ad Body**: Write a persuasive product description that highlights benefits, addresses the target audience, and encourages clicks. Keep it concise (100-150 words).
3.  **Call to Action**: Suggest a clear call-to-action phrase. (e.g., "Shop Now", "Discover More", "Get Yours").
4.  **Campaign Identifier**: Create a short, descriptive, and kebab-case string for the 'utm_campaign' parameter. This should reflect the product and the campaign purpose (e.g., "perfume-wave-ocean-breeze-launch"). Do not include "utm_campaign=" in this output.
5.  **Suggested Ad Image Description**: Describe an ideal image or video concept that would accompany this ad to maximize engagement. Be specific about the visual elements.

Generate the output in JSON format according to the provided schema.
`,
});

const generateFacebookAdContentFlow = ai.defineFlow(
  {
    name: 'generateFacebookAdContentFlow',
    inputSchema: GenerateFacebookAdContentInputSchema,
    outputSchema: GenerateFacebookAdContentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);

    if (!output) {
      throw new Error('Failed to generate ad content.');
    }

    // Construct the Facebook landing page URL with UTM parameters
    const campaignIdentifier = output.campaignIdentifier.replace(/[^a-zA-Z0-9-]/g, '').toLowerCase(); // Sanitize for URL
    const facebookLandingPageUrl = new URL(input.productUrl);
    facebookLandingPageUrl.searchParams.set('utm_source', 'facebook');
    facebookLandingPageUrl.searchParams.set('utm_medium', 'paid_social');
    facebookLandingPageUrl.searchParams.set('utm_campaign', campaignIdentifier);

    return {
      ...output,
      facebookLandingPageUrl: facebookLandingPageUrl.toString(),
    };
  }
);
