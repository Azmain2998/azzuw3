"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product, quantity: number, selectedOption?: string) => void;
  removeItem: (id: string, selectedOption?: string) => void;
  updateQuantity: (id: string, quantity: number, selectedOption?: string) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart));
      } catch (e) {
        console.error('Failed to parse cart');
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(items));
  }, [items]);

  const addItem = (product: Product, quantity: number, selectedOption?: string) => {
    // Calculate price based on selected option if priceMap exists
    const finalPrice = product.optionPrices && selectedOption 
      ? product.optionPrices[selectedOption] 
      : product.price;

    setItems((prev) => {
      const existing = prev.find(
        (item) => item.id === product.id && item.selectedOption === selectedOption
      );
      if (existing) {
        return prev.map((item) =>
          item.id === product.id && item.selectedOption === selectedOption
            ? { ...item, quantity: item.quantity + quantity, price: finalPrice }
            : item
        );
      }
      return [...prev, { ...product, quantity, selectedOption, price: finalPrice }];
    });
    toast({
      title: "Added to cart",
      description: `${product.name} (${selectedOption || 'Standard'}) added to your shopping bag.`,
    });
  };

  const removeItem = (id: string, selectedOption?: string) => {
    setItems((prev) => prev.filter((item) => !(item.id === id && item.selectedOption === selectedOption)));
  };

  const updateQuantity = (id: string, quantity: number, selectedOption?: string) => {
    if (quantity < 1) return;
    setItems((prev) =>
      prev.map((item) =>
        item.id === id && item.selectedOption === selectedOption
          ? { ...item, quantity }
          : item
      )
    );
  };

  const clearCart = () => setItems([]);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <CartContext.Provider value={{
      items,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      totalItems,
      totalPrice
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
